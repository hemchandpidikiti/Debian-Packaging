Litmus Test app :
This app facilitates the user to perform some Litmus test in an interactive way by filling the beaker with an solution and dipping litmus paper in the beaker gives out the result of color change  for predicting whether the solution is acid or base or salt
